import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teacher-student-list',
  templateUrl: './teacher-student-list.component.html',
  styleUrls: ['./teacher-student-list.component.css']
})
export class TeacherStudentListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
